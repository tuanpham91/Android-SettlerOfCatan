package com.example.tuan.myapplication.Model;

import java.util.ArrayList;
import java.util.List;

public class Player {
	
	private int points;
	private int brick ;
	private int lumber ;
	private int wool;
	private int grain;
	private int ore;
	private boolean turn;
	private boolean diceRolled;
	public int id; 
	private String name;
	private boolean banditRight;	

	private int countKnight;
	private List<House> houses;
	private List<Road> roads;
	
	public Player() {
		this.points = 0;
		this.brick = 0;
		this.lumber = 0;
		this.wool = 0;
		this.ore = 0;
		this.grain = 0;
		this.countKnight = 0;	
	}

	public int getPoint() {
		return this.points;
	}
	
	public boolean checkResource (Cost cost) {
		if (this.brick < cost.brick) {
			return false;
		}
		if (this.lumber < cost.lumber) {
			return false;
		}
		if (this.wool < cost.wool) {
			return false;
		}
		if (this.grain < cost.grain) {
			return false;
		}
		if (this.ore < cost.ore) {
			return false;
		}
		return true;
	}
	
	public boolean useResource(Cost cost) {
		if (this.brick < cost.brick) {
			return false;
		}
		if (this.lumber < cost.lumber) {
			return false;
		}
		if (this.wool < cost.wool) {
			return false;
		}
		if (this.grain < cost.grain) {
			return false;
		}
		if (this.ore < cost.ore) {
			return false;
		}
		this.brick -= cost.brick;
		this.lumber -= cost.lumber;
		this.wool -= cost.wool;
		this.grain -= cost.grain;
		this.ore -= cost.ore;
		return true;
	}
	
	public boolean handleBuildHouseRequest(ArrayList<Tile> tiles) {
		Cost houseCost = Cost.getCostOfHouse();
		if (!this.checkResource(houseCost)) {
			return false;
		}
		this.useResource(houseCost);
		this.houses.add(new House(tiles));
		return true;	
	}
	public void addResource(Cost res) {
		this.brick += res.brick;
		this.lumber += res.lumber;
		this.wool += res.wool;
		this.grain += res.grain;
		this.ore += res.ore;
	}
	public void updateResource(int dices) {
		if (dices == 7) {
			//Gain Robber Right for this player			
		}
		else  {
			for (House house : houses) {
				for (Tile tile : house.surroundingTiles) {
					if (tile.number == dices) {
						this.addResource(tile.yield(house.getLevel()));
					}
				}
				
			}
		}
	}
	
	
}
