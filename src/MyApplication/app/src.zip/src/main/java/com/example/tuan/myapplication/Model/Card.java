package com.example.tuan.myapplication.Model;

public enum Card {
	LONGEST_ROAD, BIGGEST_ARMY, STREET_BUILD, MONOPOLY , KNIGHT , INVENTION;
}