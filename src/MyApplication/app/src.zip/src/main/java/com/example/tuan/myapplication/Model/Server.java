package com.example.tuan.myapplication.Model;

public class Server {
	public Game game;
	public Server() {
		this.game = new Game();
	}
	  
	public void sendPlayersInfo() {
	  
	}	
	
	public void handleRequest() {
		
	}
}
