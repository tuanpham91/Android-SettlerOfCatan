package com.example.tuan.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Shader;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.ScrollView;



import java.util.ArrayList;

/**
 * Created by Tuan on 26.05.2017.
 */

public class CustomPlayView extends ImageView {
    public int scrollerX;
    public int scrollerY;

    public CustomPlayView(Context context) {
        super(context);
        invalidate();

        this.setOnTouchListener(new View.OnTouchListener() {

            public boolean onTouch(View arg0, MotionEvent event) {
                float curX, curY;
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        scrollerX = (int) event.getX();
                        scrollerY = (int) event.getY();
                        break;
                    case MotionEvent.ACTION_UP:
                        curX = event.getX();
                        curY = event.getY();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        curX = event.getX();
                        curY = event.getY();
                        scrollBy((int) (scrollerX - curX)/10, (int) (scrollerY - curY)/10);
                        break;
                }
                return true;
            }
        });
    }
    /*
    @Override
    public void onScroll(MotionEvent e1 , MotionEvent e2,  float disX, float disY) {


    }
    */


    @Override
    public void onDraw(Canvas canvas) {
        setBackgroundResource(R.drawable.ocean_background);
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.grain_tile);
        Bitmap bitmap1 = BitmapFactory.decodeResource(getResources(),R.drawable.wood_tile);
        Bitmap bitmap2 = BitmapFactory.decodeResource(getResources(),R.drawable.ore_tile);
        Bitmap bitmap3 = BitmapFactory.decodeResource(getResources(),R.drawable.brick_tile);
        Bitmap bitmap4 = BitmapFactory.decodeResource(getResources(),R.drawable.grass_tile);
        Bitmap bitmap5 = BitmapFactory.decodeResource(getResources(),R.drawable.desert_tile);
        ArrayList<Bitmap> bitmaps = new ArrayList<>();
        bitmaps.add(bitmap);
        bitmaps.add(bitmap1);
        bitmaps.add(bitmap2);
        bitmaps.add(bitmap3);
        bitmaps.add(bitmap4);
        bitmaps.add(bitmap5);

        int radius = 100;
        Bitmap finalBitmap = getCroppedBitmap(bitmap,radius);
        final Rect rect = new Rect(0, 0 , finalBitmap.getWidth(),
                finalBitmap.getHeight());
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);


        for (int k = 0 ; k<4;k++) {
            for (int i = 0; i < 6; i++) {
                canvas.drawBitmap(getCroppedBitmap(bitmaps.get((i+k)%6),radius), (int) (180 + i * Math.sqrt(3) * (radius +5) + (k%2)*Math.sqrt(3)/2*(radius+5)), (int)(180 + k*1.5*(radius+5)), paint);
            }
        }

    }

    public static Bitmap getCroppedBitmap(Bitmap bitmap, int radius) {
        int rad = radius ;
        Bitmap finalBitmap = Bitmap.createScaledBitmap(bitmap,(int) (Math.sqrt(3)*rad),rad*2,false);

        Bitmap output = Bitmap.createBitmap(finalBitmap.getWidth(),
                finalBitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, finalBitmap.getWidth(),
                finalBitmap.getHeight());

        /*change these value or make it dynamic*/

        Hex hex = new Hex(rad,(int) (rad*Math.sqrt(3)/2) ,rad);
        canvas.drawARGB(0, 0, 0, 0);

        paint.setColor(Color.parseColor("#BAB399"));
        canvas.drawPath(hex.getPath(), paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(finalBitmap, rect, rect, paint);

        return output;
    }

}
