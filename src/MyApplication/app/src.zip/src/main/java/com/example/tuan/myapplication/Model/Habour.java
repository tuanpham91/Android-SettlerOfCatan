package com.example.tuan.myapplication.Model;

public class Habour {
	private ExchangeRate exchangeRate; 
	
	public Habour (ExchangeRate ex) {
		this.exchangeRate = ex;
	}
	
	
}
