package com.example.tuan.myapplication.Model;

public class Tile {
	public int number;
	public TileType type;
	public ExchangeRate exchangeRate;
	public Tile() {
		
	}
	public Tile(TileType a) {
		this.type = a;
	}
	public void setType (TileType a) {
		this.type = a;
	}
	public void setNumber(int a) {
		this.number = a;
	}

	public Cost yield(int factor) {
		if (this.type == TileType.BRICK) {
			return new Cost(1,0,0,0,0);
		}
		if (this.type == TileType.LUMBER) {
			return new Cost(0,1,0,0,0);
		}
		if (this.type == TileType.WOOL) {
			return new Cost(0,0,1,0,0);
		}
		if (this.type == TileType.GRAIN) {
			return new Cost(0,0,0,1,0);
		}
		if (this.type == TileType.ORE) {
			return new Cost(0,0,0,0,1);
		}
		else {
			return new Cost(0,0,0,0,0);
		}
	} ;

	
}

enum  TileType{
	BRICK, LUMBER, WOOL, ORE, ANYTHING, GRAIN, DESERT;
}

