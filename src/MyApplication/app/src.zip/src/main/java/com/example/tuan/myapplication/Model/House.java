package com.example.tuan.myapplication.Model;

import java.util.ArrayList;

public class House extends Building {
	private int level;
	private Position pos;
	public ArrayList<Tile> surroundingTiles;
	
	public House (ArrayList<Tile> tiles) {
		this.level = 1;
		this.surroundingTiles = tiles;
	}
	
	public boolean upgrade() {
		if (this.level ==2) {
			return false;
		}
		this.level = 2;
		return true;
	}
	
	public Cost yieldResource() {
		Cost yield = new Cost();
		for (Tile tile : surroundingTiles) {
			
		}
		return new Cost(0,0,0,0,0);
	}
	public int getLevel() {
		return this.level;
	}
	
	
}
