package com.example.tuan.myapplication.Model;

public class Position {
	public int row;
	public int column;
	
	public Position(int a, int b) {
		this.row = a;
		this.column = b;
	}
}
