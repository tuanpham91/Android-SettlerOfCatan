package com.example.tuan.myapplication.Model;

public abstract class Building {
	
}
