package com.example.tuan.myapplication;

import android.graphics.Path;
import android.util.Log;

/**
 * Created by Tuan on 26.05.2017.
 */

public class Hex {
    public int radius;
    public int pointX;
    public int pointY;

    public Hex (int rad, int x , int y) {
        this.radius = rad;
        this.pointX = x;
        this.pointY = y;
    }
    public Path getPath() {

        float triangleHeight = (float) (Math.sqrt(3) * radius / 2);
        float centerX = pointX;
        float centerY = pointY;
        Path hexagonBorderPath = new Path();
        hexagonBorderPath.moveTo(centerX , centerY -radius);
        hexagonBorderPath.lineTo(centerX + triangleHeight, centerY - radius/2);
        hexagonBorderPath.lineTo(centerX + triangleHeight , centerY + radius/2);
        hexagonBorderPath.lineTo(centerX, centerY + radius);
        hexagonBorderPath.lineTo(centerX - triangleHeight, centerY + radius/2);
        hexagonBorderPath.lineTo(centerX - triangleHeight, centerY - radius/2);
        hexagonBorderPath.close();

        return hexagonBorderPath;
    }
}
