package com.example.tuan.myapplication.Model;

public class ExchangeRate {
	public Tile fromMaterial;
	public Tile toMaterial;
	public int rate;
	
	public ExchangeRate(Tile from, Tile to, int rate) {
		this.fromMaterial = from;
		this.toMaterial = to;
		this.rate = rate;
	}
}
