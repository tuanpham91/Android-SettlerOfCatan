package com.example.tuan.myapplication.Model;

import java.util.List;
import java.util.Random;

public class Game {
	private List<Player> players;
	private int playerCount; 
	private static int maxPlayers = 4;
	private static int pointsToWin = 10;
	public int playerQueqe;
	public Map map;
	public Game() {
		
	}
	public boolean addPlayer(Player player)  {
		if (this.playerCount >= maxPlayers) {
			return false;
		}
		players.add(player);
		return true;
	}
	
	public Dice rollDice (Player player) {
		Random ran = new Random();
		int dice1 = ran.nextInt(6)+1;
		int dice2 = ran.nextInt(6)+1;
		return new Dice(dice1,dice2);		
	}
	
	public int checkWinner() {
		for (Player player : players) {
			if  (player.getPoint() >= pointsToWin) {
				return player.id;
			}
		}
		return 0;
	}
}
