package com.example.tuan.myapplication.Model;

import java.util.ArrayList;
import java.util.Random;

public class Map {
	public ArrayList<Tile> tiles;
	public int row;
	public int column;
	public Map (int row , int column) {
		this.row = row;
		this.column = column;
		Tile desert = new Tile();
		desert.setType(TileType.DESERT);
		tiles.add(desert);
		for (int i = 0; i< row*column-1; i++) {
			tiles.add(ranTile(i%5));
		}
	}
	
	public static Tile ranTile (int i) {
		switch (i) {
		case 0:
			return new Tile(TileType.WOOL);
		case 1 :
			return new Tile(TileType.BRICK);
		case 2 : 
			return new Tile(TileType.LUMBER);
		case 3 : 
			return new Tile(TileType.GRAIN);
		case 4 :
			return new Tile(TileType.ORE);
		default :
			return new Tile(TileType.ORE);
		}
	}
}
