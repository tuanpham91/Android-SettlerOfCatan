package com.example.tuan.myapplication.Model;

public class Dice {
	private int dice1;
	private int dice2;
	
	public Dice (int a, int b) {
		this.dice1 = a;
		this.dice2 = b;
	}
}
