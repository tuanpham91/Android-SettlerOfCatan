package com.example.tuan.myapplication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

//import com.example.tuan.myapplication.Model.Map;

/**
 * Created by Tuan on 23.05.2017.
 */

public class PlayActivity extends AppCompatActivity {
    public void onCreate(Bundle savedBundle) {
        super.onCreate(savedBundle);
        //Map map = new Map(3,5);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        CustomPlayView customPlayView = new CustomPlayView(getApplicationContext());
        setContentView(customPlayView);
    }
}