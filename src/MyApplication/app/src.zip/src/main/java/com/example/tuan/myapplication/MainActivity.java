package com.example.tuan.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        final EditText nameText = (EditText) findViewById(R.id.nameField);
        final EditText passwordText = (EditText) findViewById(R.id.passwordField);
        Button proceedButton = (Button) findViewById(R.id.proceedButton);

        proceedButton.setOnClickListener( new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                 //if (!nameText.getText().toString().equals("") && !passwordText.getText().toString().equals("")) {
                     Intent intent = new Intent(getApplicationContext(), PlayActivity.class);
                     intent.putExtra("Player",nameText.getText().toString());
                     startActivity(intent);
                 //}
            }
        });
    }
}
