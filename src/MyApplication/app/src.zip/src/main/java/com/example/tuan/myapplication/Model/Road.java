package com.example.tuan.myapplication.Model;

public class Road extends Building {
	private Position tile1;
	private Position tile2;
	
	public Road(Position pos1, Position pos2) {
		this.tile1 = pos1;
		this.tile2 = pos2;
	}
	
}
